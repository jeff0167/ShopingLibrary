﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopingRest_Controller.Models
{
    public class MySecrets
    {
        public static readonly string path = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ShoppingItems;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
    }
}
