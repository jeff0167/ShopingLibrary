﻿using System;

namespace ShopingLibrary
{
    public class Class1
    {
    }
}
